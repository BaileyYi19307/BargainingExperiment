from otree.api import *


doc = """
Your app description
"""


class C(BaseConstants):
    NAME_IN_URL = 'triangles'
    PLAYERS_PER_GROUP = None
    NUM_ROUNDS = 1


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    button_clicked=models.BooleanField(initial=False)


class Player(BasePlayer):
    #number of points the player has
    pass


# PAGES
class MyPage(Page):
    @staticmethod

    #the server
    def live_method(player, data):
        print('received a bid from', player.id_in_group, ":", data)
        return {player.id_in_group: player.id_in_group}


page_sequence = [MyPage]
